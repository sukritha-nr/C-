﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO.PocketMoneyDTO
{
    public class PocketMoneyBean
    {
        private int serialno;

        public int Serialno
        {
            get { return serialno; }
            set { serialno = value; }
        }

        private string description;

        public string Description
        {
            get { return description; }
            set { description = value; }
        }


        private string transactionType;

        public string TransactionType
        {
            get { return transactionType; }
            set { transactionType = value; }
        }

        private double amount;

        public double Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        private double balance;

        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }

        private string date;

        public string Date
        {
            get { return date; }
            set { date = value; }
        }






    }
}
