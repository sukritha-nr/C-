﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL.PocketMoneyBL;
using DTO.PocketMoneyDTO;

namespace PL
{
    public partial class PocketMoney : Form
    {
        public PocketMoney()
        {
            InitializeComponent();
            
        }

        private void PocketMoney_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pocketMoneyDBDataSet1.pocket_money' table. You can move, or remove it, as needed.
            this.pocket_moneyTableAdapter.Fill(this.pocketMoneyDBDataSet1.pocket_money);
            LoadDetails();
            LoadDetailsIds();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            PocketMoneyBean pocketMoney = null;
            int output = 0;
            

            try
            {

                if (txtNo.Text == string.Empty && txtDescription.Text == string.Empty && txtAmount.Text == string.Empty && dateTimePicker1.Text==string.Empty)
                {
                    lblMessage.Text = "Please enter the details !!!";
                }
                else
                {
                    pocketMoney = new PocketMoneyBean();
                    if (txtNo.Text == string.Empty)
                    {
                        lblMessage.Text = "Please enter the No !!!";
                    }
                    else
                    {
                        pocketMoney.Serialno = Convert.ToInt32(txtNo.Text);
                    }
                    if (txtDescription.Text == string.Empty)
                    {
                        lblMessage.Text = "Please enter Description !!!";
                        return;
                    }
                    else
                    {
                        pocketMoney.Description = txtDescription.Text;
                    }

                    if (!rbtDebit.Checked && !rbtCredit.Checked)
                    {
                        lblMessage.Text = "Please select any type !!!";
                        return;

                    }
                    else if (rbtDebit.Checked)
                    {
                        pocketMoney.TransactionType = "Debit";
                    }
                    else
                    {
                        pocketMoney.TransactionType = "Credit";
                    }

                    if (txtAmount.Text == string.Empty)
                    {
                        lblMessage.Text = "Please enter Amount !!!";
                        return;
                    }
                    else
                    {
                        pocketMoney.Amount = Convert.ToInt64(txtAmount.Text);
                    }
                    //pocketMoney.Balance = Convert.ToInt64(txtBalance.Text);
                    double balanceamount = MoneyBLL.GetBalanceAmount(pocketMoney.Amount, pocketMoney.TransactionType);
                    pocketMoney.Balance = balanceamount;
                    pocketMoney.Date = dateTimePicker1.Value.ToString("yyyy-MM-dd");
                    output = MoneyBLL.DetailsInsert(pocketMoney);

                    if (output > 0)
                    {
                        lblMessage.Text = "Successfully added";
                        LoadDetails();
                        LoadDetailsIds(); 

                    }
                    else
                    {
                        lblMessage.Text = "Try again later";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }



        private void LoadDetails()                                          //show details in grid
        {
            DataSet dsDetails = null;
            try
            {
                //dsDetails = new DataSet();
                dsDetails = MoneyBLL.GetDetails();

                if (dsDetails != null)
                {
                    dgv.DataSource = dsDetails.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No Data available";
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }



        private void LoadDetailsIds()                                    //show ids in combobox
        {
            DataSet dsDetailsIds = null;
            try
            {
                dsDetailsIds = MoneyBLL.GetDetailsIds();
                if (dsDetailsIds != null)
                {
                    cmbId.DataSource = dsDetailsIds.Tables[0];
                    cmbId.ValueMember = "serial_no";

                    cmbId.DisplayMember = "serial_no";

                }
                else
                {
                    lblMessage.Text = "No students available";
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }




        private void btnDelete_Click(object sender, EventArgs e)
        {
            int output = 0;
            try
            {
                if (MessageBox.Show("Do you want to delete ? ", "S I S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    output = MoneyBLL.DetailsDelete(cmbId.Text);

                    if (output > 0)
                    {
                        lblMessage.Text = " details deleted successfully";
                        LoadDetails();
                        LoadDetailsIds();
                    }
                    else
                    {
                        lblMessage.Text = "Try again later";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void cmbId_SelectedIndexChanged(object sender, EventArgs e)
        {
            PocketMoneyBean pocketMoney = null;
            try
            {
                pocketMoney = MoneyBLL.GetDetailsByIds(Convert.ToInt32(cmbId.Text));

                if (pocketMoney != null)
                {
                    txtNo.Text = pocketMoney.Serialno.ToString();
                    txtDescription.Text = pocketMoney.Description;
                    dateTimePicker1.Text = pocketMoney.Date.ToString();
                    txtAmount.Text = Convert.ToInt64(pocketMoney.Amount).ToString();
                   


                }
            }
            catch (Exception ex)
            {
               //lblMessage.Text = ex.Message.ToString();
                Console.Out.WriteLine("*****Error ", ex.Message.ToString());
            }

        }

        private void ClearControl()
        {
            txtNo.Text = "";

            txtDescription.Text = "";

            txtAmount.Text = "";
          
            dateTimePicker1.Text = "";
           
            lblMessage.Text = "";
        }


        private void btnClear_Click(object sender, EventArgs e)
        {
           
                if (btnClear.Text == "BACK")
                {  
                btnClear.Text = "CLEAR";

                }
                else
                {
                    ClearControl();
                }
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            PocketMoneyBean pocketMoney = null;
            int output = 0;

            try
            {

                pocketMoney = new PocketMoneyBean();
                pocketMoney.Serialno = Convert.ToInt32(txtNo.Text);
                pocketMoney.Description = txtDescription.Text;
                pocketMoney.Amount = Convert.ToInt64(txtAmount.Text.ToString());      
                pocketMoney.Date = dateTimePicker1.Value.ToString("yyyy-MM-dd");

                if (rbtDebit.Checked == true)                                                //radio button
                {
                    pocketMoney.TransactionType = rbtDebit.Text;
                }
                else
                {
                    pocketMoney.TransactionType = rbtCredit.Text;
                }

                output = MoneyBLL.DetailsUpdate(pocketMoney);

                if (output > 0)
                {
                    lblMessage.Text = "Updated Successfully";
                    
                    LoadDetails();
                    LoadDetailsIds();
                }
                else
                {
                    lblMessage.Text = "Train again later";
                }
            }



            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void textBoxsearch_TextChanged(object sender, EventArgs e)
        {
          
                DataSet dsDetailsIds = null;
                try
                {
                    dsDetailsIds = MoneyBLL.GetLikeIds(textBoxsearch.Text);
                    if (dsDetailsIds != null)
                    {
                        dgv.DataSource = dsDetailsIds.Tables[0];

                    }
                    else
                    {
                        lblMessage.Text = "No students available";
                    }

                }
                catch (Exception ex)
                {
                    lblMessage.Text = ex.Message.ToString();
                }
            
       }
    }
}
    

