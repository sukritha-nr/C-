﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DSL.Helper;
using DTO.PocketMoneyDTO;


namespace DSL.PocketMoneyDSL
{
    public class MoneyDSL
    {
        public static int DetailsInsert(PocketMoneyBean pocketMoney)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;



            try
            {

                sql = "insert into pocket_money (serial_no,description,transaction_type,amount,balance,date)values(";
                sql = sql + pocketMoney.Serialno + ",";                            //int
                sql = sql + "'" + pocketMoney.Description + "',";                   //varchar
                sql = sql + "'" + pocketMoney.TransactionType + "',";
                sql = sql + "'" + pocketMoney.Amount + "',";
                sql = sql + pocketMoney.Balance + ",";
                sql = sql + "'" + pocketMoney.Date + "')";

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : MoneyDSL.cs::DetailsInsert", ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }


            return output;


        }

        public static DataSet GetDetails()
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsDetails = null;


            try
            {
                sql = "select * from pocket_money";
                con = DBHelper.GetConnection();
                con.Open();
                dsDetails = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsDetails);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : MoneyDSL.cs::GetDetails", ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();

            }

            return dsDetails;
        }




        public static DataSet GetDetailsIds()
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;


            DataSet dsDetailsIds = null;

            try
            {
                sql = "select serial_no from pocket_money";
                con = DBHelper.GetConnection();
                con.Open();
                dsDetailsIds = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsDetailsIds);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : MoneyDSL.cs::GetDetailsIds", ex.Message.ToString());

            }
            finally
            {
                con.Close();
                adapter.Dispose();

            }
            return dsDetailsIds;
        }




        public static PocketMoneyBean GetDetailsByIds(int Serialno)
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;


            DataSet dsDetails = null;
            PocketMoneyBean pocketMoney = null;

            try
            {
                sql = "select * from pocket_money where serial_no ='" + Serialno + "'"; ;


                con = DBHelper.GetConnection();
                con.Open();
                dsDetails = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsDetails);
                Object[] Data = null;


                if (dsDetails.Tables[0].Rows.Count > 0)
                {
                    Data = dsDetails.Tables[0].Rows[0].ItemArray;
                    pocketMoney = new PocketMoneyBean();
                    pocketMoney.Serialno= Convert.ToInt32(Data[0].ToString());
                    pocketMoney.Description= Data[1].ToString();
                    pocketMoney.TransactionType = Data[2].ToString();
                    pocketMoney.Amount = Convert.ToInt64(Data[3].ToString());                
                    pocketMoney.Date = Data[5].ToString();


                }
            }


            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : MoneyDSL.cs::GetDetailsByIds", ex.Message.ToString());

            }
            finally
            {
                con.Close();
                adapter.Dispose();

            }
            return pocketMoney;
        }









        public static int DetailsDelete(string Serialno)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;


            try
            {

                sql = "delete from pocket_money where serial_no='" + Serialno + "'"; ;

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressDSL.cs::AddressDelete", ex.Message.ToString());

            }
            finally
            {
                con.Close();
                cmd.Dispose();

            }
            return output;

        }



        public static int DetailsUpdate(PocketMoneyBean pocketMoney)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;


            try
            {
                sql = "update pocket_money set ";
                sql = sql + "description='" + pocketMoney.Description + "',";
                sql = sql + "date='" + pocketMoney.Date + "',";

                sql = sql + "transaction_type='" + pocketMoney.TransactionType + "',";
                sql = sql + "amount='" + pocketMoney.Amount + "',";
                sql = sql + "balance='" + pocketMoney.Balance + "'";
               
                sql = sql + "where serial_no =" + pocketMoney.Serialno;



                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressDSL.cs::AddressUpdate", ex.Message.ToString());

            }
            finally
            {
                con.Close();
                cmd.Dispose();

            }
            return output;



        }
        public static DataSet GetLikeIds(string like)
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsDetails = null;


            try
            {
                sql = "select * from pocket_money where serial_no like '" +like +"%'";
                con = DBHelper.GetConnection();
                con.Open();
                dsDetails = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsDetails);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : MoneyDSL.cs::GetDetails", ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();

            }

            return dsDetails;
        }
        public static double GetLastbalanceamount()
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsTransactions = null;
            double balanceAmount = 0;
            Object[] Data = null;
            try
            {
                sql = "select balance from pocket_money order by serial_no desc";
                con = DBHelper.GetConnection();
                con.Open();
                dsTransactions = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsTransactions);
                if (dsTransactions.Tables[0].Rows.Count > 0)
                {
                    Data = dsTransactions.Tables[0].Rows[0].ItemArray;
                    balanceAmount = Convert.ToInt32(Data[0].ToString());
                }
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error : PocketMoneyDS : GetBalanceAmount() " + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return balanceAmount;
        }
    }
}
