﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DSL.PocketMoneyDSL;
using DTO.PocketMoneyDTO;
using DSL.Helper;


namespace BLL.PocketMoneyBL
{
    public class MoneyBLL
    {
        public static int DetailsInsert(PocketMoneyBean pocketMoney)
        {
            int output = 0;

            try
            {
                output = MoneyDSL.DetailsInsert(pocketMoney);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : MoneyBLL.cs::DetailsInsert", ex.Message.ToString());
            }


            return output;


        }


        public static DataSet GetDetailsIds()
        {
            DataSet dsDetailsIds = null;

            try
            {

                dsDetailsIds = MoneyDSL.GetDetailsIds();


            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressBLL.cs::GetDetailsIds", ex.Message.ToString());

            }

            return dsDetailsIds;
        }




        public static int DetailsDelete(string Serialno)
        {
            int output = 0;


            try
            {

                output = MoneyDSL.DetailsDelete(Serialno);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressBLL.cs::AddressDelete", ex.Message.ToString());

            }


            return output;

        }




        public static DataSet GetDetails()
        {
            //string sql = "";

            DataSet dsDetails = null;


            try
            {

                dsDetails = MoneyDSL.GetDetails();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : MoneyBLL.cs::GetDetails", ex.Message.ToString());
            }


            return dsDetails;
        }




        public static PocketMoneyBean GetDetailsByIds(int Serialno)
        {

            PocketMoneyBean pocketMoney = null;

            try
            {
                pocketMoney = MoneyDSL.GetDetailsByIds(Serialno);
            }



            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : MoneyBLL.cs::GetDetailsByIds", ex.Message.ToString());

            }

            return pocketMoney;
        }


        public static int DetailsUpdate(PocketMoneyBean pocketMoney)
        {
            int output = 0;


            try
            {

                output = MoneyDSL.DetailsUpdate(pocketMoney);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : MoneyBLL.cs::DetailsUpdate", ex.Message.ToString());

            }


            return output;

        }

        public static DataSet GetLikeIds(string like)
        {
            DataSet dsDetailsIds = null;

            try
            {

                dsDetailsIds = MoneyDSL.GetLikeIds(like);


            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressBLL.cs::GetDetailsIds", ex.Message.ToString());

            }

            return dsDetailsIds;
        }
        public static double GetBalanceAmount(double amount,string transactionType)
        {

            double dsBalance = 0;
            try
            {

                dsBalance = MoneyDSL.GetLastbalanceamount();
                if(dsBalance != 0)
                {
                    if(transactionType == "Credit")
                    {
                        dsBalance = dsBalance + amount;
                    }
                    else
                    {
                        dsBalance = dsBalance - amount;
                    }
                }
                else
                {
                    dsBalance = 5000;
                    
                }

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : MoneyBLL.cs::GetDetails", ex.Message.ToString());
            }


            return dsBalance;
        }

    }
}
