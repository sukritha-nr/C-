﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Debugg
{
    class ClasBreakpointDemo
    {
        public static void Main()
        {
            int j = 10;
            for(int i=1;i<=10;i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine("Number is even"+i);
                    j += 2;

                }
                else
                {
                    Console.WriteLine("Number is odd"+i);
                    j -= 2;
                }
            }

            Console.ReadKey();
        }


    }
}
