﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PerfectNo
    {
        int n, sum = 0;
        

        public void ReadData()
        {
            Console.WriteLine("enter the no");
            n = Convert.ToInt32(Console.ReadLine());

        }
        public void FindPrime()
        {
            int i;
            int num = n;


            for (i=1;i<num;i++)
            {
                if(num%i==0)
                {
                    sum = sum + i;
                }
                
            }
            
            

            
        }
        public void display()
        {
            
            if (sum==n)
            {
                Console.WriteLine("Perfect No");
            }
            else
            {
                Console.WriteLine("Not perfect");
            }
        }

        public static void Main()
        {
            PerfectNo p = new PerfectNo();
            p.ReadData();
            p.FindPrime();
            p.display();
            Console.ReadKey();
        }
            
    }
}
