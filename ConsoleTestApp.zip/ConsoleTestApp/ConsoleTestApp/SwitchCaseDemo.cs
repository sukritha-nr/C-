﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SwitchCaseDemo
    {
        public static void Main()
        {
            int option;
            do
            {
                Console.WriteLine("**************************");
                Console.WriteLine(" 1 . Digit Sum");
                Console.WriteLine(" 2 . Check Prime");
                Console.WriteLine(" 3 . Exit");
                Console.WriteLine("**************************");
                Console.WriteLine("enter the option (1-3)");
                option = Convert.ToInt32(Console.ReadLine());







                switch (option)
                {
                    case 1:
                        DigitSum aa = new DigitSum();
                        aa.ReadData();
                        aa.FindDigitSum();
                        aa.DisplayData();
                        break;
                    case 2:
                        PrimeNo bb = new PrimeNo();
                        bb.ReadData();
                        bb.CheckPrime();
                        bb.DisplayData();
                        break;
                    case 3:
                        System.Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Wrong option");
                        break;
                }
            }

            while (true);



            

            
        }
    }
}
