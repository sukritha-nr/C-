﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleTestApp.ConditionalAttribute
{
    class CondiionalAttributeDEmo
    {
        public static void Main()
        {
            //Greet gg = new Greet();
            Greet.GreetDebug();
            Greet.GreetTrace();


        }
    }


    class Greet
    {
        
       
        public static void GreetDebug()
        {
            Console.WriteLine("Greeting from Debug");
        }

        
        public static void GreetTrace()
        {
            Console.WriteLine("Greeting from Trace");
        }


    }
}
