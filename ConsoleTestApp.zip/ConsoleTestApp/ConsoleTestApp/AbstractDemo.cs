﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class AbstractDemo
    {
        public static void Main()
        {
            XYZ xyz = new XYZ();
            xyz.display();
            xyz.print();
            xyz.Check();
            int v6=ABC.FindSum(10, 20);
            Console.WriteLine("val3" +v6);
            Console.ReadKey();
        }
    }

    abstract class ABC
    {
        //int val1;
        //int val2;
        const double pi = 3.14;

        public abstract void display();

        public static int FindSum(int v1,int v2)
        {
            int v4 = v1;
            int v5 = v2;
            
           int val3=v1 + v2;
            return val3;
            
        }
        public void print()
        {
            Console.WriteLine("I am within Print Method");

        }

    }

    class XYZ : ABC
    {
        int val3;
        public void Check()
        {
            Console.WriteLine("I am within Check MEthod");

        }
        public override void display()
        {
            Console.WriteLine("I am within Display Method");
            
        }
    }
}
