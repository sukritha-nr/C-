﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Seales
{
    class SealedClassDemo
    {


    }
   //sealed 
    //class Util
    //{
    //    public sealed virtual void calculate()
    //    {

    //    }
    //}




    //class helper : Util
    //{
    //    public override void calculate()
    //}


}
