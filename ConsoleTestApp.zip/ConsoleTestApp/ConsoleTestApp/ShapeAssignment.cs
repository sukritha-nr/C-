﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ShapeAssignment
    {
        public static void Main()
        {
            square q = new square();
            rectangle r = new rectangle();

            q.ReadData();
            q.FindArea();
            q.display();

            r.ReadData();
            r.FindArea();
            r.display();

            Console.ReadKey();
        



        }

    }
    abstract class shape
    {
        double pi = 3.14;
        public double area;
        public abstract void FindArea();
        public void display()
        {
            Console.WriteLine("AREA " + area);
        }

        
        
    }

    class square : shape
    {
        int a;
        public void ReadData()
        {
            Console.WriteLine("enter the side");
            a = Convert.ToInt32(Console.ReadLine());


        }
        public override void FindArea()
        {
            area = a * a;
        }
    }

    class rectangle : shape
    {
        int l,b;
        public void ReadData()
        {
            Console.WriteLine("enter the length");
            l = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter the bredth");
            b= Convert.ToInt32(Console.ReadLine());

        }
        public override void FindArea()
        {
            area = l * b;
        }
    }


}
