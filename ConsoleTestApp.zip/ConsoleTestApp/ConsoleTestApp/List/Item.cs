﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.List
{
    class ShoppingDemo
    {

        public static void Main()
        {
            Hashtable products = new Hashtable();
            Hashtable cart = new Hashtable();
            products.Add(1, new Item(101, "Vivel", 45));
            products.Add(2, new Item(102, "Santhoor", 32));
            products.Add(3, new Item(103, "Pears", 50));
            products.Add(4, new Item(104, "Dove", 38));
            products.Add(5, new Item(105, "Yardly", 55));


            Item item;

            int choice;

            do
            {
                Console.WriteLine("----------------------------------------");
                Console.WriteLine("        1 : ADD CART");
                Console.WriteLine("        2 : VIEW CART");
                Console.WriteLine("        3 : CHECKOUT CART");
                Console.WriteLine("        4 : EXIT");
                Console.WriteLine("----------------------------------------");
                Console.WriteLine("Enter the Choice");
                choice = Convert.ToInt32(Console.ReadLine());


                switch(choice)
                {
                    case 1:
                        Console.WriteLine("---------------- PRODUCT DETAILS --------------");
                        ICollection keys = products.Keys;
                        foreach (int key in keys)
                        {
                            Console.WriteLine("******************************\n", key);
                            item = ((Item)products[key]);
                            Console.WriteLine("    Product ID = {0}\n    Product Name = {1}\n    Unit Price = {2}", item.ProductID, item.ProductName, item.UnitPrice);
                            Console.WriteLine("******************************");
                        }
                        Console.WriteLine("Enter Product ID");
                        int product_ID = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Product Quantity");
                        int quantity = Convert.ToInt32(Console.ReadLine());
                        if (cart == null)
                        {
                            cart = new Hashtable();
                        }
                        else
                        {
                            foreach (int key in keys)
                            {
                                item = ((Item)products[key]);
                                if (item.ProductID == product_ID)
                                {
                                    int amount = item.UnitPrice * quantity;
                                    string productName = item.ProductName;
                                    int unitPrice = item.UnitPrice;
                                    cart.Add(key, new Item(product_ID, productName, quantity, unitPrice, amount));
                                    Console.WriteLine("Product added to Cart Successfully");
                                }
                            }

                        }


                        break;


                    case 2:
                       
                        ICollection keysCart = cart.Keys;
                        foreach (int key in keysCart)
                        {
                            Console.WriteLine("******************************\n", key);
                            Console.WriteLine("\n            In Your Cart");
                            Console.WriteLine("--------------------------------------\n");


                           item = ((Item)cart[key]);
                            Console.WriteLine("    Product ID = {0}\n    Product Name = {1}\n    Qantity = {2}\n    Total Amount = {3}", item.ProductID, item.ProductName, item.Quantity, item.Amount);
                           
                            
                        }



                        break;

                    case 3:
                        int total = 0;
                        Console.WriteLine("\n---------- Products purchased -------------");
                        ICollection keyCart = cart.Keys;
                        Console.WriteLine("    Product ID  |   Product Name  |   Quantity |   Unit Price    |   Amount");
                        foreach (int key in keyCart)
                        {
                            
                            item = ((Item)cart[key]);

                            Console.WriteLine("     {0}         |   {1}             |   {2}         |   {3}         |   {4}", item.ProductID, item.ProductName, item.Quantity, item.UnitPrice, item.Amount);
                            total += item.Amount;
                           
                        }
                        Console.WriteLine("**************************************************************");
                        Console.WriteLine("                                TOTAL AMOUNT{0}        ", total);




                        break;
                    case 4:
                        
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\n!!!... Wrong option , Please enter 1-4.");
                        break;
                }

                
            } while (true);
            
        }
    }
    public class Item
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public int UnitPrice { get; set; }
        public int Quantity { get; set; }
        public int Amount { get; set; }

        public Item(int id, string name, int price)
        {
            ProductID = id;
            ProductName = name;
            UnitPrice = price;
        }
        public Item(int id, string productName, int quantity, int unitPrice, int amount)
        {
            ProductID = id;
            ProductName = productName;
            Quantity = quantity;
            UnitPrice = unitPrice;
            Amount = amount;
        }
        public void AddCart()
        {
            Console.WriteLine("Enter Product Key");
            int key = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Quantity");
            int quantity = Convert.ToInt32(Console.ReadLine());

        }

    }
}