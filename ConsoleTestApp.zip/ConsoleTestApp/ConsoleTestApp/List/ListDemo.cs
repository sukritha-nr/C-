﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.List
{
    class ListExample
    {
        public static void Main(String[]args)
        {
            List<String> names = new List<String>();
            names.Add("Sukritha");
            names.Add("Ankit");
            names.Add("Peter");
            names.Add("Irfan");
            names.Add("Ankit");
            names.Add("Peter");
            names.Insert(0, "Gokul");

            //names.Add("1234");
            //names.Add(new Message());
            //names.RemoveAt(0);
            //names.RemoveRange(2, 2);
            //names.Reverse();
            //names.Sort();


            foreach(var name in names)
            {
                Console.WriteLine(name);
            }
            Console.ReadLine();



        }

        //public static void HashTableDemo()
        //{
        //    Hashtable ht = new Hashtable();
        //    ht.Add("001", "SSSSs");
        //    ht.Add("002", "QQQQQ");
        //    ht.Add("003", "PPPP");
        //    ht.Add("004", "TTTTT");
        //    ht.Add("005", "rrrrrrr");
        //    if(ht.ContainsValue("AAAAA"))
        //    {
        //        Console.WriteLine("This student is already exist");

        //    }
        //    else
        //    {
        //        ht.Add("007", "AAAAA");
        //    }
        //    ICollection key = ht.keys;
        //    foreach(string k in key)
        //    {
        //        Console.WriteLine(k + ":" + ht[k]);
        //                        }
        }
           

    }

