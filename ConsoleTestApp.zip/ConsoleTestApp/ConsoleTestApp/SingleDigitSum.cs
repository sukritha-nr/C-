﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SingleDigitSum
    {

        //int n;
        ////int digitSum;





        //public void ReadData()
        //{
        //    Console.WriteLine("enter a number");
        //    n = Convert.ToInt32(Console.ReadLine());
        //}


        //public void DisplayData()
        //{
        //    Console.WriteLine("thesingle digit sum is:", n);
        //}

        //public int DigitSm(int n)
        //{
        //    int sum = 0;

        //    while(n>0 || sum>9)
        //    {
        //        if(n==0)
        //        {
        //            n = sum;
        //            sum = 0;

        //        }
        //        sum += n % 10;
        //        n /= 10;
        //    }





        }





















        //public void FindDigitSum() 
        //{
        //    int n = number;
        //    int lastDigit;
        //    do

            
        //        {
        //            lastDigit = n % 10;
        //            digitSum += lastDigit;
        //            n /= 10;
        //        } while (n > 0) ;

        //    int ds = digitSum;
        //    int ls, d = 0;
        //        if (digitSum>9)
        //        {
        //        do
        //        {
        //            ls = ds % 10;
        //            d += ls;
        //            n /= 10;
        //        } while (ds> 0);



        //        }
            

        //}
        //public static void Main()
        //{
        //    DigitSum aa = new DigitSum();
        //    aa.ReadData();
        //    aa.FindDigitSum();
        //    aa.DisplayData();
        //    Console.ReadKey();


        //}
    }


