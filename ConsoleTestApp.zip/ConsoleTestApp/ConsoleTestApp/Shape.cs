﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Shape
    {
        public static void display(int l, int b)
        {
            Console.WriteLine("Area of rectangle is " +l*b);
        }
        
        public static void display(double r)
        {
            double pi = 3.14;
            Console.WriteLine("Area of circle is "+pi*r*r);
        }
        public static void display(int c, double h)
        {
            
            Console.WriteLine("Area of triangle is " +0.5 * c * h);
        }

        public static void Main()
        {
            display(10, 20);
            display(10);
            display(10, 20);
            Console.ReadKey();
        }



    }
}
