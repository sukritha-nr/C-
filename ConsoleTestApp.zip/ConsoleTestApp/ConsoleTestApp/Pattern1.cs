﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Pattern1
    {
        int i, j, n = 5;
        public void PrintPattern()
        {
            for (i = 0; i <= n; i++)
            {
                Console.WriteLine("\n");
                for (j = 1; j <= i; j++)
                {
                    Console.Write(" * ");

                }


                    Console.WriteLine();
                
            }
                
            
        }

        public static void Main()
        {
            Pattern1 oo = new Pattern1();
            oo.PrintPattern();
            Console.ReadKey();

        }

    }
}

    

    
       