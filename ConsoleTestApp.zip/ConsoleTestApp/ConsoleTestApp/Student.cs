﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Student
    {
        int MinMark=0, MaxMark=100,PassMark=45;
        int id,mark1;
        string name;

        public void ReadData()
        {
            Console.Write("enter the student id    : " );
            id = Convert.ToInt32(Console.ReadLine());

            Console.Write("enter the student name   : ");
            name = Convert.ToString(Console.ReadLine());

            Console.Write("enter the student mark1   : ");
            mark1 = Convert.ToInt32(Console.ReadLine());

           

        }
        
        public void FindTrue()
        {
            bool flag = false;
            do
            {
                if (mark1 < MinMark || mark1 > MaxMark)
                {
                    flag = true;
                    Console.WriteLine("invalid mark");
                    Console.WriteLine("enter the valid mark1");
                    mark1 = Convert.ToInt32(Console.ReadLine());
                    DisplayMark();
                }
            } while (flag);
           


        }
        public void DisplayMark()
        {
            if(mark1<=PassMark)
            {
                Console.WriteLine("FAILED");

            }
            else
            {
                Console.WriteLine("PASS");

            }
        }

        public static void Main()
        {
            Student h = new Student();
            h.ReadData();
            h.FindTrue();
            h.DisplayMark();
            Console.WriteLine("press enter");
            Console.ReadKey();

            Student a = new Student();
            a.ReadData();
            a.FindTrue();
            a.DisplayMark();
            Console.WriteLine("press enter");
            Console.ReadKey();

            Student z = new Student();
            z.ReadData();
            z.FindTrue();
            z.DisplayMark();
            Console.ReadKey();
        }

    }
}
