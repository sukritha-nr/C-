﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class InheritanceMethod
    {
        public static void Main()
        {
            Aa i = new Aa();
            Bb b = new Bb(10,30);
            //i.displayA();
            b.dissplay();
            Console.ReadKey();


        }
    }

    class Aa
    {
        public int val1;
        public Aa()
        {
            val1 = 10;
        }
        public Aa(int v1)
        {
            val1 = v1;

        }
           
        
        public virtual void dissplay()
        {
            Console.WriteLine("Am from class A  val1 :" + val1);
        }
    }

    class Bb : Aa
    {
        int val2;
        public Bb()
        {
            val2 = 20;

        }
        public Bb(int v1,int v2) :base(v1)
        {
            val2 = v2;

        }
        public override void  dissplay()
        {
            Console.WriteLine("Am from class A val1 :" + val1);
            Console.WriteLine("Am from class B val2 :" + val2);
        }
    }



}

