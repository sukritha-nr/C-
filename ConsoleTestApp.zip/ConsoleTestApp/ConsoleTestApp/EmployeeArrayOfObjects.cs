﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleTestApp
{
    class EmployeeArrayOfObjects
    {
        public static void Main()
        {
            Employee[] arrayEmployee = new Employee[2];
            Console.WriteLine("Enter Employee Details");
            for (int employee = 0; employee < arrayEmployee.Length; employee++)
            {
                Console.WriteLine("\nEnter Details of Employee {0}", employee + 1);
                Console.WriteLine("******************************");
                arrayEmployee[employee] = new Employee();
                arrayEmployee[employee].ReadEmployee();
            }
            Console.WriteLine("\n\nEmployee Details");
            for (int employee = 0; employee < arrayEmployee.Length; employee++)
            {
                Console.WriteLine("Details of Employee {0}", employee + 1);
                Console.WriteLine(arrayEmployee[employee]);
            }

            Console.ReadKey();
        }

    }
    class Employee
    {
        int employeeId, basicSalary;
        String name;
        double hra, ta, da;
        public void ReadEmployee()
        {
            Console.Write("Enter Employee Id : ");
            employeeId = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter Employee Name : ");
            name = Console.ReadLine();
            Console.Write("\nEnter Employee Basic Salary : ");
            basicSalary = Convert.ToInt32(Console.ReadLine());
        }
        public override string ToString()
        {
            String output = "";
            output += "*******************************\n";
            output += "Employee ID : {0}" + employeeId;
            output += "\nEmployee Name : {0}" + name;
            output += "\nEmployee Basic Salary : {0}" + basicSalary;
            output += "\nEmployee HRA : {0}" + hra;
            output += "\nEmployee DA : {0}" + da;
            output += "\nEmployee TA : {0}" + ta;
            output += "\n*******************************\n";

            return output;
        }
        public void Calculate()
        {
            hra = (20 / 100) * basicSalary;
            da = (70 / 100) * basicSalary;
            ta = (15 / 100) * basicSalary;
        }
    }
}