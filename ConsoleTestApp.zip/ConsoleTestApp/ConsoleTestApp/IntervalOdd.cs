﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class IntervalOdd
    {
        int interval1, interval2,i=0;
        public void ReadData()
        {
            Console.WriteLine("enter first intervl");
            interval1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter last intervl");
            interval2 = Convert.ToInt32(Console.ReadLine());
        }
        public void FindOdd()
        {
            for(i=interval1;i<=interval2;i++)
            {
                if(i%2!=0)
                {
                    Console.WriteLine(i);
                }

            }

        }
        public static void Main(string[] args)
        {
            
            IntervalOdd aa = new IntervalOdd();
            aa.ReadData();
            Console.WriteLine("the odd no are");
            aa.FindOdd();
            Console.ReadKey();
        }
    }
}
