﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PrimeNo
    {
        int p;
        string result;
        public void ReadData()
        {

            Console.WriteLine("enter a number");
            p = Convert.ToInt32(Console.ReadLine());
        }
        public void CheckPrime()
        {
            bool flag = true;

            for (int no = 2; no < p; no++)
            {

                if (p % no == 0)
                {
                    flag = false;
                    break;
                }
            }
            if (flag)
            {
                result = "PRIME";

            }
            else
            {
                result = "NOT PRIME";
            }



        }
        
        public void DisplayData()
        {
            Console.WriteLine("The give number {0} is {1}", this.p, this.result);




        }
        public static void Main(string[] args)
        {
            PrimeNo bb = new PrimeNo();
            bb.ReadData();
            bb.CheckPrime();
            bb.DisplayData();
            Console.ReadKey();
        }
        


        }



    }

