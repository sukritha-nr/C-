﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Reverse
    {
        int n;
        int sum = 0;
        int rev;

        public void ReadData()
        {
            Console.WriteLine("enter the number");
            n = Convert.ToInt32(Console.ReadLine());
        }
        public void FindReverse()
        {
            while (n != 0)
            {

                rev = n % 10;
                sum = sum * 10 + rev;
                n = n / 10;
            }

        }
        public void Display()
        {
            Console.WriteLine("the rev no is  : "+sum);
        }

        public static void Main()
        {
            Reverse r = new Reverse();
            r.ReadData();
            r.FindReverse();
            r.Display();
            Console.ReadKey();
        }

    }
}
