﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class OddSum
    {
        int i,n;
        int sum = 0;
        public void ReadData()
        {
            Console.WriteLine("enter the limit");
            n = Convert.ToInt32(Console.ReadLine());

        }
        public void FindSum()
        {
            for(i=1;i<=n;i++)
            {
                sum = sum + i;
                i = i + 1;
            }
        }
        public void DisplaySum()
        {
            Console.WriteLine("the sum is" + sum);

        }
        public static void Main()
        {
            OddSum a = new OddSum();
            a.ReadData();
            a.FindSum();
            a.DisplaySum();
            Console.ReadKey();
        }
           
    }
}
