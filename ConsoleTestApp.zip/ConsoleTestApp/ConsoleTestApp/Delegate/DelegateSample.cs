﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Delegate
{
    public delegate void Calculate(int val1, int val2);
    class DelegateSample
    {

        public static void Main()
        {
            Calculator cc = new Calculator();
            Calculate calculate = new Calculate(Calculator.Sum);
            calculate += Calculator2.Sub;
            calculate+=cc.Mul;

            calculate(10, 20);
            Console.ReadLine();
        }
    }

    class Calculator
    {
        public static void Sum(int value1,int value2 )
        {
            Console.WriteLine(value1 + value2);
        }

        public  void Mul(int value1, int value2)
        {
            Console.WriteLine(value1 * value2);
        }

    }

    class Calculator2
    {
        public static void Sub(int value1, int value2)
        {
            Console.WriteLine(value1 - value2);
        }
    }
}
