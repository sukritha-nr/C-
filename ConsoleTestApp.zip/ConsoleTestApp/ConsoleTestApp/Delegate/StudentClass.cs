﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Delegate
{
    public delegate bool IsPromotableDelegatee(StudentClass studentClass); 
        
    class Studentelegate
    {
        public static void Main()
        {
            List<StudentClass> studentList = new List<StudentClass>();
            studentList.Add(new StudentClass { ID = 1, Name = "ASD", Mark = 64, });
            studentList.Add(new StudentClass { ID = 2, Name = "SER", Mark = 77, });
            studentList.Add(new StudentClass { ID = 3, Name = "DFG", Mark = 26, });
            studentList.Add(new StudentClass { ID = 4, Name = "CVB", Mark = 70, });
            studentList.Add(new StudentClass { ID = 5, Name = "BNM", Mark = 33, });

            Console.WriteLine("The Promoted Lists are");
            Console.WriteLine("");

            IsPromotableDelegatee isPromotableDelegate = new IsPromotableDelegatee(IsPromotable);
            StudentClass.GetPromotionList(studentList, isPromotableDelegate);

            Console.ReadKey();





        }

        public static bool IsPromotable(StudentClass studentClass)
        {
            bool eligible = false;
            if (studentClass.Mark > 50)
            {
                eligible = true;

            }
            return eligible;
        }
    }


    public class StudentClass
    {
        public int ID { get; set; }
        public String Name { get; set; }
        public int Mark { get; set; }

        public static void GetPromotionList(List<StudentClass> students, IsPromotableDelegatee isPromotableDelegate)
        {
            foreach (StudentClass studentClass in students)
            {
                if (isPromotableDelegate(studentClass))
                {
                    Console.WriteLine("Student Id {0}", studentClass.ID);
                    Console.WriteLine("Student Name {0}", studentClass.Name);

                    Console.WriteLine("Student Mark {0}", studentClass.Mark);
                }
            }
        }
    }
}
















