﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ConsoleTestApp.Delegate
//{
//    class EmployeeDetail
//    {

         

//        public static void Main()
//        {
//            List<EmployeeDetail> employeeListt = new List<EmployeeDetail>();
//            employeeListt.Add(new EmployeeDetail { ID = 10, Name = "SSS", Salary = 40000, Experience = 4 });
//            employeeListt.Add(new EmployeeDetail { ID = 11, Name = "RRR", Salary = 50000, Experience = 5 });
//            employeeListt.Add(new EmployeeDetail { ID = 12, Name = "TTTT", Salary = 67000, Experience = 3 });
//            employeeListt.Add(new EmployeeDetail { ID = 13, Name = "KKKK", Salary = 86000, Experience = 8 });
//            employeeListt.Add(new EmployeeDetail { ID = 14, Name = "OOOO", Salary = 30000, Experience = 7 });


//            Console.WriteLine("list is ");
//            Console.WriteLine("***************");
//            Employee.GetPromotionList(employeeListt);
//            Console.ReadLine();
//        }
//    }




//    public class EmployeeDetail
//    {
//        public int ID { get; set; }
//        public String Name { get; set; }
//        public int Experience { get; set; }
//        public int Salary { get; set; }

//        public static void GetPromotionListt(List<EmployeeDetail> employees)
//        {
//            foreach (EmployeeDetail employee in employees)
//            {
//                if (employee.Experience >= 5)
//                {
//                    Console.WriteLine("Empolyee ID {0}", employee.ID);
//                    Console.WriteLine("Empolyee Name {0}", employee.Name);

//                    Console.WriteLine("Empolyee Salary {0}", employee.Salary);

//                    Console.WriteLine("Empolyee Experience {0}", employee.Experience);



//                }
//            }
//        }
//    }
//}


    