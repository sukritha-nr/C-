﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Delegate
{
    public delegate bool IsPromotableDelegate(Employee employee);

    class DelegateEmployeePromotion
    {

        public static void Main()
        {
            List<Employee> employeeList = new List<Employee>();
            employeeList.Add(new Employee { ID = 10, Name = "SSS", Salary = 40000, Experience = 4 });
            employeeList.Add(new Employee { ID = 11, Name = "RRR", Salary = 50000, Experience = 5 });
            employeeList.Add(new Employee { ID = 12, Name = "TTTT", Salary = 67000, Experience = 3 });
            employeeList.Add(new Employee { ID = 13, Name = "KKKK", Salary = 86000, Experience = 8 });
            employeeList.Add(new Employee { ID = 14, Name = "OOOO", Salary = 30000, Experience = 7 });


            Console.WriteLine("list is ");
            Console.WriteLine("***************");


            //Employee.GetPromotionList(employeeList);



            IsPromotableDelegate isPromotableDelegate = new IsPromotableDelegate(IsPromotable);
            Employee.GetPromotionList(employeeList, isPromotableDelegate);

           
            Console.ReadLine();
        }



        public static bool IsPromotable(Employee employee)
        {
            bool eligible = false;
            if (employee.Experience >= 4 && employee.Salary < 50000)
            {
                eligible = true;
            }
            return eligible;
        }
    }




    public class Employee
    {
        public int ID { get; set; }
        public String Name { get; set; }
        public int Experience { get; set; }
        public int Salary { get; set; }




        //public static void GetPromotionList(List<Employee> employees)
        //{
        //    foreach (Employee employee in employees)
        //    {
        //        if (employee.Experience >= 5)
        //        {
        //            Console.WriteLine("Empolyee ID {0}", employee.ID);
        //            Console.WriteLine("Empolyee Name {0}", employee.Name);

        //            Console.WriteLine("Empolyee Salary {0}", employee.Salary);

        //            Console.WriteLine("Empolyee Experience {0}", employee.Experience);



        //        }
        //    }
        //}




        public static void GetPromotionList(List<Employee> employees, IsPromotableDelegate isPromotableDelegate)
        {
            foreach (Employee employee in employees)
            {
                if (isPromotableDelegate(employee))
                {
                    Console.WriteLine("Empolyee ID {0}", employee.ID);
                    Console.WriteLine("Empolyee Name {0}", employee.Name);

                    Console.WriteLine("Empolyee Salary {0}", employee.Salary);

                    Console.WriteLine("Empolyee Experience {0}", employee.Experience);

                }
            }
        }
    }
}

