﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PrimeInterval
    {
        int interval1, interval2;
        string result;
        public void ReadData()
        {
            Console.WriteLine("enter first intervl");
            interval1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter last intervl");
            interval2 = Convert.ToInt32(Console.ReadLine());
        }
        public Boolean FindPrime(int n)
        {
            bool flag = true;
            int i;
            for (i = 2; i < n - 1; i++)
            {
                if (n % 2 == 0)
                {
                    flag = false;
                    break;
                }

            }
            return flag;
        }
        public void CheckPrimeInterval()
        {


            int i;
            for (i = interval1; i <= interval2; i++)
            {
                if (FindPrime(i))
                {
                    Console.WriteLine(i);
                }
            }
        }
        public static void Main()
        {
            PrimeInterval ss = new PrimeInterval();
            ss.ReadData();
            ss.CheckPrimeInterval();
            Console.ReadKey();
        }
    }
}
    
    








           





