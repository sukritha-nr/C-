﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Circle
    {
        double r,area,cir;
        double pi = 3.14159;

        public void ReadRadious()
        {
            Console.WriteLine("enter the radious");
            r = Convert.ToInt32(Console.ReadLine());
        }
        public void Area()
        {
            area = pi * r * r;
            Console.WriteLine("area is "+area);


        }
        public void Circum()

        {
            cir = 2 * pi * r;
            Console.WriteLine("circumference is :  " +cir);


        }
        public static void Main()
        {
            Circle c = new Circle();
            c.ReadRadious();
            c.Area();
            c.Circum();
            Console.ReadKey();
        }

    }
}
