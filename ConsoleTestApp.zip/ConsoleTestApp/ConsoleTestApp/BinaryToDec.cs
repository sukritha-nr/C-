﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace ConsoleTestApp
{
    class BinaryToDec
    {
        int binaryNo, decimalNo;
        public BinaryToDec()
        {


        }
        public BinaryToDec(int b)
        {
            binaryNo = b;
        }
                                    
        
        public void Converrt()
        {
            int n = binaryNo;
            int ld;
            int i = 0;

            do
            {
                ld = n % 10;
                decimalNo +=ld*(int)Math.Pow(2, i);
                n /= 10;
                i++;

            } while (n > 0);
        }
        public void Display()
        {
            Console.WriteLine("the decimal no is"+decimalNo);

        }

        public static void Main()
        {
            BinaryToDec bd = new BinaryToDec(100);
           

            bd.Converrt();
            bd.Display();
                
            Console.ReadKey();



                
            
        }


    }
}
