﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Sum
    {
        int value1, value2, value3;

        public void ReadData()
        {
            Console.WriteLine("Enter the 1st no  :");
            value1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the 2nd no  :");
            value2 = Convert.ToInt32(Console.ReadLine());
        }

        public void FindSum()
        {
            value3 = value1 + value2;
        }

        public void DisplaySum()
        {
            Console.WriteLine("Sum is  :" + value3);
        }
       

        public static void Main(string[]args)
        {
            Sum objsum = new Sum();
            objsum.ReadData();
            objsum.FindSum();
            objsum.DisplaySum();
            Console.ReadKey();

        }
    }
}
