﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Pattern6
    {

        int number;
        public void ReadData()
        {
            Console.Write("Enter the number : ");
            number = Convert.ToInt32(Console.ReadLine());

            Console.Write("\n");
        }


        public void print()
        {
            for (int no = number; no >= 1; no--)
            {

                int k = 0;
                for (int i = number - no; i >= 1; i--)
                {
                    Console.Write("  ");
                }

                for (int j = no; j >= 1; j--)
                {
                    Console.Write(" *");
                    k++;
                }

                for (; k > 1; k--)
                {
                    Console.Write(" *");
                }
                Console.WriteLine("\n");
            }
        }

        public static void Main()
        {
            Pattern6 Objdigit1 = new Pattern6();
            Objdigit1.ReadData();
            Objdigit1.print();

            Console.ReadKey();
        }


    }
}

