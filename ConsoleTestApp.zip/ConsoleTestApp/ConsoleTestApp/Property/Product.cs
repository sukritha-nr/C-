﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Property
{
    class Product
    {
        public static void Main()
        {
           SS p = new SS();
            p.ProductName = "AAAAAA";
            p.Price = 100;
            p.SupplierId = 44;
            Console.WriteLine("the Product Name is : " + p.ProductName);
            Console.WriteLine("the Product Price is : " + p.Price);
            Console.WriteLine("the Supplier Id is : " + p.SupplierId);
            Console.WriteLine("the Product id is : " +p.ProductId );
            Console.WriteLine("");



           SS pp = new SS();
            pp.ProductName = "bbbbbb";
            p.Price = 128;
            pp.SupplierId = 45;
            Console.WriteLine("the Product Name is : " + pp.ProductName);
            Console.WriteLine("the Product Price is : " + pp.Price);
            Console.WriteLine("the Supplier Id is : " + pp.SupplierId);
            Console.WriteLine("the Product id is : " + pp.ProductId);


            Console.ReadKey();

        }
    }
    class SS
    {


        public readonly int ProductId;
        static int tmp = 101;
        public SS()
        {
            ProductId = tmp;
            tmp++;
        }

        private string productName;
        private int price;
        private int supplierId;

        public string ProductName
        {
            get { return productName; }
            set { productName = value; }

        }

        public int Price
        {
            get { return price; }
            set { price = value; }

        }

        public int SupplierId
        {
            get { return supplierId; }
            set { supplierId = value; }

        }




    }
}


