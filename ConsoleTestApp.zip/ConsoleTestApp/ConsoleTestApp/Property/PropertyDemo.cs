﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Property
{
    class PropertyDemo
    {
        public static void Main()
        {
            Company c = new Company();
            c.CompanyId = 100;
            c.CompanyName = "QuEST";
            c.Address = "TECHNOPARK";
            Console.WriteLine("COMPANY ID : " + c.CompanyId);
            Console.WriteLine("COMPANY NAME : " + c.CompanyName);
            Console.WriteLine("COMPANY ADDRESS : " + c.Address);

            Console.ReadKey();

        }
    }
    class Company
    {
        private int companyId;
        private string companyName;
        private string address;

        public int CompanyId
        {
            get { return companyId; }
            set { companyId = value; }
        }

        public string CompanyName
        {
            get { return companyName; }
            set { companyName = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
            
        }
    }
      
}



