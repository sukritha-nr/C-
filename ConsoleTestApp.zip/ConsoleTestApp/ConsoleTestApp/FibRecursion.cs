﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class FibRecursion

    {

        //public static void Main()
        //{
        //    FibRecursion fib = new FibRecursion();
        //    Console.WriteLine("enter the limit");
        //    n = Convert.ToInt32(Console.ReadLine());

        //}








        //int n, i;

        //public  int Fibnocci(int num)
        //{

        //    int a = 0;
        //    int b = 1;

        //    while (i <= n)
        //    {
        //        i = a + b;
        //        Console.WriteLine(i);
        //        a = b;
        //        b = i;
        //    }
        //}















    }
}

