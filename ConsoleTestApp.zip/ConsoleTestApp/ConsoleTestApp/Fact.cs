﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Fact
    {
        int n;
        int f = 1;
        public void ReadData()
        {
            Console.WriteLine("enter the number");
            n = Convert.ToInt32(Console.ReadLine());

        }
        public void FindFact()
        {
            int i;
            for (i=1;i<=n;i++)
            {
                f=f*i;



            }
        }
        public void DisplayFact()
        {
            Console.WriteLine("factorial is\n"+f);
        }
        public static void Main()
        {
            Fact ff = new Fact();
            ff.ReadData();
            ff.FindFact();
            ff.DisplayFact();
            Console.ReadKey();
        }


    }
}
