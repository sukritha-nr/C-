﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Inheritance
    {
        public static void Main()
        {
            A i = new A();
            B b = new B();
            i.displayA();
            b.displayB();
            Console.ReadKey();


        }
    }

    class A
    {
        public int val1;
        public A()
        {
            val1 = 10;
        }
        public void displayA()
        {
            Console.WriteLine("Am from class A  val1 :" + val1);
        }
    }

    class B : A
    {
        int val2;
        public B()
        {
            val2 = 20;

        }
        public void displayB()
        {
            Console.WriteLine("Am from class A val1 :" + val1);
            Console.WriteLine("Am from class B val2 :" + val2);
        }
    }





}
