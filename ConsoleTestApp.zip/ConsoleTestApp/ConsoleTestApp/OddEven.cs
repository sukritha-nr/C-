﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class OddEven
    {
        int n;
        public void ReadData()
        {
            Console.WriteLine("Enter the 1st no  :");
            n = Convert.ToInt32(Console.ReadLine());
        }
        public void DisplayResult()
        {
            if(n %2==0)
            {
                Console.WriteLine("Number is even");

            }
            else
            {
                Console.WriteLine("Number is odd");
            }
        }

        public static void Main(string[] args)
        {
            OddEven obj = new OddEven();
            obj.ReadData();
            obj.DisplayResult();
            Console.ReadKey();
        }
           
    }
}
