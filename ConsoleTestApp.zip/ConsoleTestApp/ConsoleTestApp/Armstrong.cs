﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Armstrong
    {
        int n,armstrong=0;

        public void ReadData()
        {
            Console.WriteLine("enter the no");
            n = Convert.ToInt32(Console.ReadLine());
        }
       

        public void Amst()
        {
            int ld;
            int num=n;
           
            do
            {
                ld = num % 10;
                armstrong +=(int)Math.Pow(ld,3);
                num /= 10;
                

            } while (num > 0);
        }
        public void Display()
        {
            if (armstrong == n)
            {


                Console.WriteLine("Armstrong");
            }
            else
            {
                Console.WriteLine("Not Armstrong");

            }

        }

        public static void Main()
        {
            Armstrong a = new Armstrong();
            a.ReadData();
            a.Amst();
            a.Display();

           
            Console.ReadKey();





        }


    }
}
