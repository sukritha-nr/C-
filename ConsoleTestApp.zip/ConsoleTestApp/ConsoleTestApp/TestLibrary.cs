﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary2;

namespace ConsoleTestApp
{
    class TestLibrary
    {
        public static void Main()
        {
            Calculatorr c1 = new Calculatorr();
            c1.Display();
            Console.ReadKey();


        }
    }
}
