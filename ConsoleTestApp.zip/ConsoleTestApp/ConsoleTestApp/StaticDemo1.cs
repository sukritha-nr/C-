﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class StaticDemo1
    {
        int i = 5;
        static int j=5;

        public void Inc()
        {
            Console.WriteLine("the i value is :" + i);
            Console.WriteLine("the j value is :" + j);

            i++;
            j++;
        }
        public static void Main()
        {
            StaticDemo1 a = new StaticDemo1();
            StaticDemo1 b = new StaticDemo1();
            StaticDemo1 c = new StaticDemo1();
            StaticDemo1 d = new StaticDemo1();

            a.Inc();
            b.Inc();
            c.Inc();
            d.Inc();

            Console.ReadKey();


        }
            

        
    }
}
