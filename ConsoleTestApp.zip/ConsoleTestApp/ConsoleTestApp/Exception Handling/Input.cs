﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Exception_Handling
{
    class Input
    {
        public static void Main()
        {
            Console.WriteLine("enter a number ");
            

            Console.ReadKey();
                 
        }
        public static int ReadI()
        {
            int value = 0;
            bool flag = true;
            do
            {
                try
                {
                    value = Convert.ToInt32(Console.ReadLine());
                    flag = false;
                }
                catch
                {
                    Console.WriteLine(" WRONG VALUE | ENTER A VALID INTEGER ");
                }

            } while (flag);
            return value;
        }



    }
}
