﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class DigitSum
    {
        int number;
        int digitSum;
       

      
       

        public void ReadData()
        {
            Console.WriteLine("enter a number");
            number = Convert.ToInt32(Console.ReadLine());
        }


        public void DisplayData()
        {
            Console.WriteLine("the digit sum of the given number {0} is {1}", number,digitSum);
        }


        public void FindDigitSum()
        {
            int n = number;
            int lastDigit;
            do
            {
                lastDigit = n % 10;
                digitSum += lastDigit;
                n /= 10;
            } while (n > 0);

        }
        public static void Main()
        {
            DigitSum aa = new DigitSum();
            aa.ReadData();
            aa.FindDigitSum();
            aa.DisplayData();
            Console.ReadKey();


        }
    }
}
