﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.array
{
    class ArraySort
    {
        int[] num;
        public void ReadData()
        {
            int n;

            Console.WriteLine("Enter the limit n : ");
            n = Convert.ToInt32(Console.ReadLine());               // given a value for array limit

            num = new int[n];

            Console.WriteLine("------------------------");
            for (int i = 0; i < num.Length; i++)
            {
                num[i] = Convert.ToInt32(Console.ReadLine());
            }
        }

        public void sort()
        {
            int temp;
            for (int i = 0; i < num.Length; i++)
            {
                for (int j = i + 1; j < num.Length; j++)
                {
                    if (num[i] > num[j])
                    {
                        temp = num[j];
                        num[j] = num[i];
                        num[i] = temp;
                    }

                }
            }
        }

        public void DisplyData()
        {
            Console.WriteLine("\nSorted Array");
            Console.WriteLine("\n------------------------\n");

            foreach (int i in num)
            {
                Console.Write(" " + i);
            }
        }

        public static void Main(string[] args)
        {
            ArraySort obj1 = new ArraySort();
            obj1.ReadData();
            obj1.sort();
            obj1.DisplyData();

            Console.ReadKey();
        }




    }
}
