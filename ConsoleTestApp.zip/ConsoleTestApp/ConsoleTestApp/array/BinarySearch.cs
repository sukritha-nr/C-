﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.array
{
    class BinarySearch
    {
        public static void Main()
        {
            int[] value = new int[6];
            int temp = 0;

            Console.WriteLine("Enter the elements ");
            for (int i = 0; i < value.Length; i++)
            {
                value[i] = Convert.ToInt32(Console.ReadLine());

            }

            Console.WriteLine("The entered values are ");
            for (int i = 0; i < value.Length; i++)
            {
                Console.WriteLine(" " + value[i]);
            }

            for (int i = 0; i < value.Length; i++)
            {
                for (int j = i + 1; j < value.Length; j++)
                {
                    if (value[i] > value[j])
                    {
                        temp = value[i];
                        value[i] = value[j];
                        value[j] = temp;
                    }
                }
            }
            Console.WriteLine();

            Console.WriteLine("The sorted array : ");
            Console.WriteLine("---------------------");

            foreach (int sort in value)
            {

                Console.WriteLine(" " + sort);

            }



            int s;
            Console.WriteLine("Enter the search element ");
            s = Convert.ToInt32(Console.ReadLine());
            bool flag = false;
            int minimum = 0;
            int maximum = value.Length - 1;
            while (minimum <= maximum)
            {
                int mid = (minimum + maximum) / 2;
                if (s == value[mid])
                {
                    flag = true;
                    break;

                }
                else
                {
                    if (s > value[mid])
                    {
                        minimum = mid + 1;
                    }
                    else
                    {
                        maximum = mid - 1;
                    }
                }
               
 


            }
            if (flag == true)
            {
                Console.WriteLine(" element founded");
            }
            else
            {
                Console.WriteLine(" element not  founded  ");
            }









            Console.ReadKey();


        }
    }
}
       









