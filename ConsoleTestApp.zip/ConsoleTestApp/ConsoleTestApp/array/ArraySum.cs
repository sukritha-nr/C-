﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.array
{
    class ArraySum
    {
        int[] values = new int[5];
        int i;

        int sum = 0;

        public static void Main()
        {
            ArraySum obj = new ArraySum();
            obj.ReadData();
            obj.FindSum();
            obj.Displya();
            Console.ReadKey();


        }

        public void ReadData()
        {
            Console.WriteLine("Enter the array elements");
            for (int i = 0; i < values.Length; i++)
            {
                values[i] = Convert.ToInt32(Console.ReadLine());
            }
        }

        public void FindSum()

        {
            for(i=0;i<values.Length;i++)
            sum += values[i];



        }

        public void Displya()
        {
            Console.WriteLine("the array sum is   :  " + sum);
        }





    }
}
