﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.array
{
    class TwoArraySum
    {
       
        int row, col;
        int[,] matrix;
        int i, j;

        public static void Main()
        {

            TwoArraySum a = new TwoArraySum();
            a.Read();
            a.Display();
            Console.ReadKey();

           
        }

        public void Read()
        {
           
            Console.WriteLine("Enter the row ");
            row = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the column ");
            col = Convert.ToInt32(Console.ReadLine());
           
            matrix = new int[row, col];

            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    
                    matrix[row,col ] = Convert.ToInt32(Console.ReadLine());
                }

            }



        }
        public void Display()
        {
            Console.Write("the matrix is " ,matrix[row,col]);
        }




    }
}
