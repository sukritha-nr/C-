﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleTestApp.StreamDemo
{
    class MergeFiles
    {

        public static void Main()
        {
            FileStream data2file = new FileStream("C:\\Users\\1028272\\Desktop\\data2.txt", FileMode.OpenOrCreate);
            for (int ii = 65; ii <= 78; ii++)
            {
                data2file.WriteByte((byte)ii);
            }
            data2file.Close();
            Console.WriteLine("File 1 created Successfully...........");
            Console.WriteLine("File 1 read operation...........");

            //FileStream data2OutFile = new FileStream("C:\\Users\\1028272\\Desktop\\data2.txt", FileMode.OpenOrCreate);
            //int i = 0;
            //while ((i = data2OutFile.ReadByte()) != -1)
            //{
            //    Console.Write((char)i);
            //}
            //data2OutFile.Close();


            //data 3
            FileStream data3file = new FileStream("C:\\Users\\1028272\\Desktop\\data3.txt", FileMode.OpenOrCreate);
            for (int jj = 79; jj <= 90; jj++)
            {
                data3file.WriteByte((byte)jj);
            }
            data3file.Close();
            Console.WriteLine("File 2 is created Successfully...........");
            Console.WriteLine("File 2 read operation");

            //FileStream data3OutFile=new FileStream("C:\\Users\\1028272\\Desktop\\data3.txt", FileMode.OpenOrCreate);
            //int j = 0;
            //while((j=data3OutFile.ReadByte()) !=-1)
            //{
            //    Console.WriteLine((char)i);
            //}
            //data3OutFile.Close();


            string[] datafile1 = File.ReadAllLines("C:\\Users\\1028272\\Desktop\\data2.txt");
            string[] datafile2 = File.ReadAllLines("C:\\Users\\1028272\\Desktop\\data3.txt");

            using (StreamWriter writer1 = File.CreateText("C:\\Users\\1028272\\Desktop\\mergedFile.txt")) 
            {
                int line = 0;
                while(line<datafile1.Length || line<datafile2.Length)
                {
                    if(line<datafile1.Length)

                        writer1.WriteLine(datafile1[line]);

                    if (line < datafile2.Length)

                        writer1.WriteLine(datafile1[line]);
                    line++;



                }
            }





            Console.ReadLine();

        }


    }
}
