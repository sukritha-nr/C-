﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleTestApp.StreamDemo
{
    class FileStreamDemo1
    {

        public static void Main()
        {
            FileStream data1file = new FileStream("C:\\Users\\1028272\\Desktop\\sukritha\\data1.txt", FileMode.OpenOrCreate);
            for(int ii=65;ii<=90;ii++)
            {
                data1file.WriteByte((byte)ii);
            }
            data1file.Close();
            Console.WriteLine("File created Successfully...........");
            Console.WriteLine("File read operation...........");

            FileStream data1OutFile = new FileStream("C:\\Users\\1028272\\Desktop\\sukritha\\data1.txt", FileMode.OpenOrCreate);
            int i = 0;
            while((i=data1OutFile.ReadByte())!=-1)
            {
                Console.Write((char)i);
            }
            data1OutFile.Close();
            Console.ReadLine();

        }

    }
}
