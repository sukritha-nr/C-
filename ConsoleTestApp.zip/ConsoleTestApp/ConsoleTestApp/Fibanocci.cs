﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Fibanocci
    {
        int n,i;
        int a = 0;
        int b = 1;
        public void ReadData()
        {
            Console.WriteLine("enter the limit");
            n = Convert.ToInt32(Console.ReadLine());
        }

        
           


            
        
        public void display()
        {
            Console.WriteLine("the fib series is :");
            Console.WriteLine(a);
            Console.WriteLine(b);
            while (i <= n)
            {
                i = a + b;
                Console.WriteLine(i);
                a = b;
                b = i;
            }
            

        }

        public static void Main()
        {
            Fibanocci f = new Fibanocci();
            f.ReadData();
            
            f.display();
            Console.ReadKey();
        }
            
    }
}
