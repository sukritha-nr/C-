﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleTestApp.thread
{

    class ThreadTableDemo
    {
        public static void Main()
        {
            TableThread table5 = new TableThread(5,2000);
            Thread thread1 = new Thread(table5.GenerateTable);
            thread1.Start();

            TableThread table10 = new TableThread(10,200);
            Thread thread2 = new Thread(table10.GenerateTable);
            thread2.Start();

            Console.ReadKey();
        }
    }
    class TableThread
    {
        private int _number;
        private int _sleep;

        public TableThread(int target,int sleep)
        {
            _number = target;
            _sleep = sleep;
        }

        public void GenerateTable()
        {
            Thread.Sleep(_sleep);
            for(int iteration =1;iteration<=10;iteration++)
            {
                Console.WriteLine("{0} * {1} = {2}", iteration, _number, (iteration * _number));
                    
            }
        }
    }
}
