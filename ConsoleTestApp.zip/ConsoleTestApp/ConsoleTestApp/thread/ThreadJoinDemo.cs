﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleTestApp.thread
{
    class ThreadJoinDemo
    {
         static void Main()
        {
            Thread thread1 = Thread.CurrentThread;
            thread1.Name = "Main Thread";
            Console.WriteLine("Main method : " + thread1.Name);

            ThreadStart threadStart1 = new ThreadStart(ChildThread1);

            Thread subThread1 = new Thread(ChildThread1);
            Thread subThread2 = new Thread(ChildThread2);

            subThread1.Start();
            subThread2.Start();

            subThread2.Join();
            Console.WriteLine("Main method completed");
            Console.WriteLine();

            Console.ReadLine();


        }




        public static void ChildThread1()
        {
            Console.WriteLine("I am Child Thread 1 ");
            for(int i=1;i<=10;i++)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
            Console.WriteLine("Child thread1 Completed");
            Console.WriteLine();
        }

        public static void ChildThread2()
        {
            Thread.Sleep(1000);
            Console.WriteLine("Iam in Child Thread 2");

            for(int i=11;i<=40;i++)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
            Console.WriteLine("Child thread2 Completed");
            Console.WriteLine();



        }
    }
}
