﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleTestApp.thread
{
    class Synchronization
    {

        public static void Main()
        {
            Printer p = new Printer();
            Thread thread = new Thread(p.PrintTable);
            thread.Start();

            

                    
            Thread thread1 = new Thread(p.PrintTable);
            thread1.Start();

            Console.ReadKey();
        }
            
        
        
    }


    class Printer
    {
        public void PrintTable()
        {
            lock(this)
            {
                for (int i= 0;i<= 10;i++)
                {
                    Thread.Sleep(200);
                    Console.WriteLine(i);

                }
            }
        }
    }
        
       
}
