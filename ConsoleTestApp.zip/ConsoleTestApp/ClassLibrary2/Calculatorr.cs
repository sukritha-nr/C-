﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class Calculatorr
    {
        public void Display()
        {
            Console.WriteLine("Iam with in DLL project");

        }
    }
}
