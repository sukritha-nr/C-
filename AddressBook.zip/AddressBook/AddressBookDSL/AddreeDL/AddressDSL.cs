﻿using System;
using System.Collections.Generic;
using System.Text;
using AddressBookDTO.DTO;
using AddressBookDSL.Helper;
using System.Data.SqlClient;
using System.Data;


namespace AddressBookDSL.AddreeDL
{
    public class AddressDSL
    {
        public static int AddressInsert(AddressBook addressBook)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;


            try
            {

                sql = "insert into address_book(contact_id,contact_name,contact_dob,contact_email,contact_mob,contact_state,contact_gender,contact_address)values(";
                sql = sql + addressBook.ContactId + ",";                            //int
                sql = sql + "'" + addressBook.ContactName + "',";                   //varchar
                sql = sql + "'" + addressBook.ContactDob + "',";
                sql = sql + "'" + addressBook.ContactEmail + "',";
                sql = sql + addressBook.ContactMobile + ",";
                sql = sql + "'" + addressBook.ContactState + "',";
                sql = sql + "'" + addressBook.ContactGender + "',";
                sql = sql + "'" + addressBook.ContactAddress + "')";

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressDSL.cs::AddressInsert", ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }


            return output;



        }




        public static int AddressDelete(string contactId)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;


            try
            {

                sql = "delete from address_book where contact_id='" + contactId + "'"; ;

                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressDSL.cs::AddressDelete", ex.Message.ToString());

            }
            finally
            {
                con.Close();
                cmd.Dispose();

            }
            return output;

        }







        public static DataSet GetAddress()
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsAddress = null;


            try
            {
                sql = "select * from address_book";
                con = DBHelper.GetConnection();
                con.Open();
                dsAddress = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsAddress);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressDSL.cs::GetAddress", ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();

            }

            return dsAddress;
        }

        public static DataSet GetAddressIds()
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;


            DataSet dsAddressId = null;

            try
            {
                sql = "select contact_id from address_book";
                con = DBHelper.GetConnection();
                con.Open();
                dsAddressId = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsAddressId);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressDSL.cs::GetAddressIds", ex.Message.ToString());

            }
            finally
            {
                con.Close();
                adapter.Dispose();

            }
            return dsAddressId;
        }



        public static AddressBook GetAddressByIds(int contactId)
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;


            DataSet dsAddress = null;
            AddressBook addressBook = null;

            try
            {
                sql = "select * from address_book where  contact_id='" + contactId + "'"; ;


                con = DBHelper.GetConnection();
                con.Open();
                dsAddress = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsAddress);
                Object[] Data = null;


                if (dsAddress.Tables[0].Rows.Count > 0)
                {
                    Data = dsAddress.Tables[0].Rows[0].ItemArray;
                    addressBook = new AddressBook();
                    addressBook.ContactId = Convert.ToInt32(Data[0].ToString());
                    addressBook.ContactName = Data[1].ToString();
                    addressBook.ContactDob = Data[2].ToString();
                    addressBook.ContactEmail = Data[3].ToString();
                    addressBook.ContactMobile = Convert.ToInt64(Data[4].ToString());
                    addressBook.ContactState = Data[5].ToString();
                    addressBook.ContactGender = Data[6].ToString();
                    addressBook.ContactAddress = Data[7].ToString();

                }
            }


            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressDSL.cs::GetAddressByIds", ex.Message.ToString());

            }
            finally
            {
                con.Close();
                adapter.Dispose();

            }
            return addressBook;
        }




        public static int AddressUpdate(AddressBook addressBook)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;


            try
            {



                sql = "update address_book set ";
                sql = sql + "contact_name='" + addressBook.ContactName + "',";
                sql = sql + "contact_dob='" + addressBook.ContactDob + "',";
                sql = sql + "contact_email='" + addressBook.ContactEmail + "',";
                sql = sql + "contact_mob='" + addressBook.ContactMobile + "',";
                sql = sql + "contact_state='" + addressBook.ContactState + "',";
                sql = sql + "contact_gender='" + addressBook.ContactGender + "',";
                sql = sql + "contact_address='" + addressBook.ContactAddress + "' ";
                sql = sql + "where contact_id =" + addressBook.ContactId;



                con = DBHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);
                output = cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressDSL.cs::AddressUpdate", ex.Message.ToString());

            }
            finally
            {
                con.Close();
                cmd.Dispose();

            }
            return output;



        }


        public static DataSet GetAddressLike(string likeName)
        {
            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;

            DataSet dsAddress = null;

            try
            {
                sql = "select * from address_book where contact_name like '" + likeName + "%'";
                con = DBHelper.GetConnection();
                con.Open();
                dsAddress = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsAddress);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressDSL.cs::GetAddressLike", ex.Message.ToString());

            }
            finally
            {
                con.Close();
                adapter.Dispose();

            }
            return dsAddress;
        }




    }




}
