﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace AddressBookDSL.Helper
{
   public class DBHelper
    {


        public static SqlConnection GetConnection()
        {

            SqlConnection con = null;
            //string connectionstring = null;

            try
            {
                String connectionstring = ConfigurationManager.ConnectionStrings["AddressBookPL.Properties.Settings.AddressDbConnectionString"].ConnectionString;              
                    //connectionstring = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = C:\\Users\\1028272\\Desktop\\sukritha\\AddressBook\\AddressBookDSL\\Data\\AddressDb.mdf; Integrated Security = True";
                con = new SqlConnection(connectionstring);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : DBHelper.cs::GetConnection", ex.Message.ToString());
            }

            return con;
        }
    }
}
