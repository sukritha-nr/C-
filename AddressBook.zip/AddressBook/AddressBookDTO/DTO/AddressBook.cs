﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBookDTO.DTO
{
    public class AddressBook
    {

        private int contactId;

        public int ContactId
        {
            get { return contactId; }
            set { contactId = value; }
        }

        private  string contactName;

        public  string ContactName 
        {
            get { return contactName; }
            set { contactName = value; }
        }

        private string contactdob;

        public string ContactDob
        {
            get { return contactdob; }
            set { contactdob = value; }
        }

        private string contactEmail;

        public string ContactEmail
        {
            get { return contactEmail; }
            set { contactEmail = value; }
        }

        private long contactMobile;

        public long ContactMobile
        {
            get { return contactMobile; }
            set { contactMobile = value; }
        }
        private string contactState;

        public string ContactState
        {
            get { return contactState; }
            set { contactState = value; }
        }

        private string contactGender;

        public string ContactGender
        {
            get { return contactGender; }
            set { contactGender = value; }
        }

        private string contactAddress;

        public string ContactAddress
        {
            get { return contactAddress; }
            set { contactAddress = value; }
        }


    }
}
