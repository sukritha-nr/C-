﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddressbookBLL.AddressBL;
using AddressBookDTO.DTO;


namespace AddressBookPL
{
    public partial class AddressBook : Form
    {
        public AddressBook()
        {
            InitializeComponent();
            AddressBook addressBook = null;
            AddressBLL.AddressInsert(addressBook)



        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void AddressBook_Load(object sender, EventArgs e)
        {

        }
    }
}
