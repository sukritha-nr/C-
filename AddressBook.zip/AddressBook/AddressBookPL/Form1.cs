﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddressbookBLL.AddressBL;
using AddressBookDTO.DTO;

namespace AddressBookPL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadAddress();
            LoadAddressIds();

        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            AddressBook addressBook = null;
            int output = 0;



            try
            {

                if (txtId.Text == string.Empty && txtName.Text == string.Empty && comboBox1.Text == string.Empty && txtEmail.Text == string.Empty && txtMob.Text == string.Empty && txtAddress.Text == string.Empty)
                {
                    lblMessage.Text = "Please enter the details !!!";
                }
                else
                {
                    addressBook = new AddressBook();
                    if (txtId.Text == string.Empty)
                    {
                        lblMessage.Text = "Please enter ID !!!";
                    }
                    else
                    {
                        addressBook.ContactId = Convert.ToInt32(txtId.Text);
                    }


                    if (txtName.Text == string.Empty)
                    {
                        lblMessage.Text = "Please enter Name !!!";
                        return;
                    }
                    else
                    {
                        addressBook.ContactName = txtName.Text;
                    }

                    addressBook.ContactEmail = txtEmail.Text;
                    if (!addressBook.ContactEmail.Contains('@'))
                    {
                        lblMessage.Text = "Enter valid email containing @";
                        return;
                    }


                    if (txtMob.Text.Length < 10 || txtMob.Text.Length > 10)                           //mobile  validation
                    {
                        lblMessage.Text = "Enter 10 digit number";
                        return;

                    }
                    else
                    {
                        addressBook.ContactMobile = Convert.ToInt64(txtMob.Text);
                    }

                    if (comboBox1.SelectedIndex == -1)
                    {
                        lblMessage.Text = "Please select a state !!!";
                        return;
                    }
                    else
                    {
                        addressBook.ContactState = comboBox1.SelectedItem.ToString();
                    }


                   



                    if (dateTimePicker1.Text == string.Empty)
                    {
                        lblMessage.Text = "Please enter DOB !!!";
                        return;
                    }
                    else
                    {
                        addressBook.ContactDob = dateTimePicker1.Value.ToString("yyyy-MM-dd");
                        
                    }


                    if (!radioBtnMale.Checked && !radioBtnFemale.Checked)
                    {
                        lblMessage.Text = "Please Select gender !!!";
                        return;
                    }

                    else if (radioBtnMale.Checked)
                    {
                        addressBook.ContactGender = "Male";
                        
                    }
                    else
                    {
                        addressBook.ContactGender = "Female";
                        
                    }

                    if (txtAddress.Text == string.Empty)
                    {
                        lblMessage.Text = "Please enter Address !!!";
                        return;
                    }
                    else
                    {
                        addressBook.ContactAddress = txtAddress.Text;
                    }




                    output = AddressBLL.AddressInsert(addressBook);
                    if (output > 0)
                    {
                        lblMessage.Text = "Successfully added";
                        LoadAddress();
                        LoadAddressIds();

                    }
                    else
                    {
                        lblMessage.Text = "Try again later";
                    }

                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }

        }


        private void LoadAddress()                                          //show details in grid
        {
            DataSet dsAddress = null;
            try
            {
                dsAddress = AddressBLL.GetAddress();

                if (dsAddress != null)
                {
                    dgvAddress.DataSource = dsAddress.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No students available";
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }
        private void LoadAddressIds()                                    //show ids in combobox
        {
            DataSet dsAddressIds = null;
            try
            {
                dsAddressIds = AddressBLL.GetAddressIds();
                if (dsAddressIds != null)
                {
                    cmbid.DataSource = dsAddressIds.Tables[0];
                    cmbid.ValueMember = "contact_id";

                    cmbid.DisplayMember = "contact_id";

                }
                else
                {
                    lblMessage.Text = "No students available";
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void cmbid_SelectedIndexChanged(object sender, EventArgs e)
        {
            AddressBook addressBook = null;
            try
            {
                addressBook = AddressBLL.GetAddressByIds(Convert.ToInt32(cmbid.Text));

                if (addressBook != null)
                {
                    txtId.Text = addressBook.ContactId.ToString();
                    txtName.Text = addressBook.ContactName;
                    dateTimePicker1.Text = addressBook.ContactDob.ToString();
                    txtEmail.Text = addressBook.ContactEmail;
                    txtMob.Text = addressBook.ContactMobile.ToString();
                    comboBox1.Text = addressBook.ContactState;

                    txtAddress.Text = addressBook.ContactAddress;


                }
            }
            catch (Exception ex)
            {
                //lblMessage.Text = ex.Message.ToString();
            }


        }

        private void btnDELETE_Click(object sender, EventArgs e)
        {
            int output = 0;
            try
            {
                if (MessageBox.Show("Do you want to delete ? ", "S I S", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    output = AddressBLL.AddressDelete(cmbid.Text);

                    if (output > 0)
                    {
                        lblMessage.Text = "Student details deleted successfully";
                        LoadAddress();
                        LoadAddressIds();
                    }
                    else
                    {
                        lblMessage.Text = "Try again later";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }



        private void btnUpdate_Click(object sender, EventArgs e)
        {

            AddressBook addressBook = null;
            int output = 0;

            try
            {

                addressBook = new AddressBook();
                addressBook.ContactId = Convert.ToInt32(txtId.Text);
                addressBook.ContactName = txtName.Text;
                addressBook.ContactEmail = txtEmail.Text;
                addressBook.ContactMobile = Convert.ToInt64(txtMob.Text);
                addressBook.ContactAddress = txtAddress.Text;

                addressBook.ContactState = comboBox1.SelectedItem.ToString();

                addressBook.ContactDob = dateTimePicker1.Value.ToString("yyyy-MM-dd");


                if (radioBtnMale.Checked == true)                                                //radio button
                {
                    addressBook.ContactGender = radioBtnMale.Text;
                }
                else
                {
                    addressBook.ContactGender = radioBtnFemale.Text;
                }

                output = AddressBLL.AddressUpdate(addressBook);

                if (output > 0)
                {
                    lblMessage.Text = "Updated Successfully";
                    // LoadStudents();
                    LoadAddress();
                    LoadAddressIds();
                }
                else
                {
                    lblMessage.Text = "Train again later";
                }
            }



            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void ClearControl()
        {
            txtId.Text = "";

            txtName.Text = "";

            txtEmail.Text = "";
            txtMob.Text = "";

            dateTimePicker1.Text = "";
            comboBox1.Text = "";
            txtAddress.Text = "";

            lblMessage.Text = "";
        }


        private void btnCLEAR_Click(object sender, EventArgs e)
        {
            if (btnCLEAR.Text == "BACK")
            {  //{
                //    btnsave.Text = "NEW";
                //    btnDELETE.Enabled = true;
                //    bbtnUpdate.Enabled = true;
                btnCLEAR.Text = "CLEAR";

            }
            else
            {
                ClearControl();
            }
        }



        private void txtNameSearch_TextChanged(object sender, EventArgs e)
        {
            DataSet dsAddress = null;
            try
            {
                dsAddress = AddressBLL.GetAddressLike(txtNameSearch.Text);
                if (dsAddress != null)
                {
                    dgvAddress.DataSource = dsAddress.Tables[0];


                }
                else
                {
                    lblMessage.Text = "No students available";
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }


        }
    }
}




    

