﻿namespace AddressBookPL
{
    partial class TestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.addressDbDataSet = new AddressBookPL.AddressDbDataSet();
            this.addressbookBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.address_bookTableAdapter = new AddressBookPL.AddressDbDataSetTableAdapters.address_bookTableAdapter();
            this.contactidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactdobDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactemailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactmobDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactstateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactgenderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactaddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addressDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addressbookBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.contactidDataGridViewTextBoxColumn,
            this.contactnameDataGridViewTextBoxColumn,
            this.contactdobDataGridViewTextBoxColumn,
            this.contactemailDataGridViewTextBoxColumn,
            this.contactmobDataGridViewTextBoxColumn,
            this.contactstateDataGridViewTextBoxColumn,
            this.contactgenderDataGridViewTextBoxColumn,
            this.contactaddressDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.addressbookBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(248, 85);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // addressDbDataSet
            // 
            this.addressDbDataSet.DataSetName = "AddressDbDataSet";
            this.addressDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // addressbookBindingSource
            // 
            this.addressbookBindingSource.DataMember = "address_book";
            this.addressbookBindingSource.DataSource = this.addressDbDataSet;
            // 
            // address_bookTableAdapter
            // 
            this.address_bookTableAdapter.ClearBeforeFill = true;
            // 
            // contactidDataGridViewTextBoxColumn
            // 
            this.contactidDataGridViewTextBoxColumn.DataPropertyName = "contact_id";
            this.contactidDataGridViewTextBoxColumn.HeaderText = "contact_id";
            this.contactidDataGridViewTextBoxColumn.Name = "contactidDataGridViewTextBoxColumn";
            // 
            // contactnameDataGridViewTextBoxColumn
            // 
            this.contactnameDataGridViewTextBoxColumn.DataPropertyName = "contact_name";
            this.contactnameDataGridViewTextBoxColumn.HeaderText = "contact_name";
            this.contactnameDataGridViewTextBoxColumn.Name = "contactnameDataGridViewTextBoxColumn";
            // 
            // contactdobDataGridViewTextBoxColumn
            // 
            this.contactdobDataGridViewTextBoxColumn.DataPropertyName = "contact_dob";
            this.contactdobDataGridViewTextBoxColumn.HeaderText = "contact_dob";
            this.contactdobDataGridViewTextBoxColumn.Name = "contactdobDataGridViewTextBoxColumn";
            // 
            // contactemailDataGridViewTextBoxColumn
            // 
            this.contactemailDataGridViewTextBoxColumn.DataPropertyName = "contact_email";
            this.contactemailDataGridViewTextBoxColumn.HeaderText = "contact_email";
            this.contactemailDataGridViewTextBoxColumn.Name = "contactemailDataGridViewTextBoxColumn";
            // 
            // contactmobDataGridViewTextBoxColumn
            // 
            this.contactmobDataGridViewTextBoxColumn.DataPropertyName = "contact_mob";
            this.contactmobDataGridViewTextBoxColumn.HeaderText = "contact_mob";
            this.contactmobDataGridViewTextBoxColumn.Name = "contactmobDataGridViewTextBoxColumn";
            // 
            // contactstateDataGridViewTextBoxColumn
            // 
            this.contactstateDataGridViewTextBoxColumn.DataPropertyName = "contact_state";
            this.contactstateDataGridViewTextBoxColumn.HeaderText = "contact_state";
            this.contactstateDataGridViewTextBoxColumn.Name = "contactstateDataGridViewTextBoxColumn";
            // 
            // contactgenderDataGridViewTextBoxColumn
            // 
            this.contactgenderDataGridViewTextBoxColumn.DataPropertyName = "contact_gender";
            this.contactgenderDataGridViewTextBoxColumn.HeaderText = "contact_gender";
            this.contactgenderDataGridViewTextBoxColumn.Name = "contactgenderDataGridViewTextBoxColumn";
            // 
            // contactaddressDataGridViewTextBoxColumn
            // 
            this.contactaddressDataGridViewTextBoxColumn.DataPropertyName = "contact_address";
            this.contactaddressDataGridViewTextBoxColumn.HeaderText = "contact_address";
            this.contactaddressDataGridViewTextBoxColumn.Name = "contactaddressDataGridViewTextBoxColumn";
            // 
            // TestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Name = "TestForm";
            this.Text = "TestForm";
            this.Load += new System.EventHandler(this.TestForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addressDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addressbookBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private AddressDbDataSet addressDbDataSet;
        private System.Windows.Forms.BindingSource addressbookBindingSource;
        private AddressDbDataSetTableAdapters.address_bookTableAdapter address_bookTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactdobDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactemailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactmobDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactstateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactgenderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactaddressDataGridViewTextBoxColumn;
    }
}