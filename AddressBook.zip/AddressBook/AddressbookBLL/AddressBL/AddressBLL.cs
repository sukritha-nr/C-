﻿using System;
using System.Collections.Generic;
using System.Text;
using AddressBookDSL.AddreeDL;
using AddressBookDTO.DTO;
using AddressBookDSL.Helper;
using System.Data;



namespace AddressbookBLL.AddressBL
{
   public class AddressBLL
    {
        public static int AddressInsert(AddressBook  addressBook)
        {
            int output = 0;

            try
            {
                output = AddressDSL.AddressInsert(addressBook);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressBLL.cs::AddressInsert", ex.Message.ToString());
            }


            return output;


        }


        public static int AddressDelete(string contactId)
        {
            int output = 0;


            try
            {

                output = AddressDSL.AddressDelete(contactId);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressBLL.cs::AddressDelete", ex.Message.ToString());

            }


            return output;

        }


        public static int AddressUpdate(AddressBook addressBook)
        {
            int output = 0;


            try
            {

                output = AddressDSL.AddressUpdate(addressBook);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressBLL.cs::AddressUpdate", ex.Message.ToString());

            }


            return output;

        }





        public static DataSet GetAddress()
        {
            string sql = "";
           
            DataSet dsAddress = null;


            try
            {

                dsAddress = AddressDSL.GetAddress();
               
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressBLL.cs::GetAddress", ex.Message.ToString());
            }
          

            return dsAddress;
        }

        public static DataSet GetAddressIds()
        {
            string sql = "";
          
            DataSet dsAddressId = null;

            try
            {

                dsAddressId = AddressDSL.GetAddressIds();
              

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressBLL.cs::GetAddressIds", ex.Message.ToString());

            }
         
            return dsAddressId;
        }




        public static AddressBook GetAddressByIds(int contactId)
        {

            AddressBook addressBook = null;

            try
            {
                addressBook = AddressDSL.GetAddressByIds(contactId);
            }



            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressBLL.cs::GetAddressByIds", ex.Message.ToString());

            }

            return addressBook;
        }


        public static DataSet GetAddressLike(string likeName)
        {


            DataSet dsStudents = null;

            try
            {
                dsStudents = AddressDSL.GetAddressLike(likeName);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("*****Error : AddressBLL.cs::GetAddressLike", ex.Message.ToString());

            }

            return dsStudents;
        }











    }
}
